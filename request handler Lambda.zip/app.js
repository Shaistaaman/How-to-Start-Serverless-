var aws = require('aws-sdk');
const ddb = new aws.DynamoDB();
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotallySecretKey');

var express = require("express");
var bodyParser = require("body-parser");
var awsServerlessExpressMiddleware = require("aws-serverless-express/middleware");

var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(awsServerlessExpressMiddleware.eventContext());

app.post("/saveData",  async (req, res) => {
  let date = new Date();
  const randomNum = Date.now().toString() + (Math.floor(Math.random() * 1000).toString());
  let params = {
    Item: {
      id: { S: randomNum },
      __typename: { S: "UserAuth" },
      username: { S: req.body.username },
      password: { S: cryptr.encrypt(req.body.password)  },
      createdAt: { S: date.toISOString() },
      updatedAt: { S: date.toISOString() },
    },
    TableName: 'UserAuth',
  };

  try {
    await ddb.putItem(params).promise();
    res.json({
      status: 200,
      message: " Data successfully added",
      id: randomNum
    });
  }
  catch (err) {
    console.log("Error cognitoSignInWithHash: ", err);
    res.json({
      status: 401,
      message: err
    });
  }
});

app.post("/getUser",  async (req, res) => {

  var params = {
    Key: {
     "id": {
       S: req.body.id
      }
    }, 
    TableName: "UserAuth"
   };

  try {
    const item = await ddb.getItem(params).promise();
    const data = aws.DynamoDB.Converter.unmarshall(item.Item);
  
    res.json({
      status: 200,
      message: 'Succcess',
      data: {
        username: data.username,
        password: cryptr.decrypt(data.password),
        id: data.id
      }
    });
  }
  catch (err) {
    console.log("Error cognitoSignInWithHash: ", err);
    res.json({
      status: 400,
      message: err
    });
  }
});

app.listen(3000, function() {
  console.log("App started");
});

module.exports = app;
